def turn(env, turn_dir):
    return []
