def craft(env, item, workshop):
    return []
