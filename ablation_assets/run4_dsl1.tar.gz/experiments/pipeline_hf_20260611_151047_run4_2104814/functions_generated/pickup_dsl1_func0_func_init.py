def pickup(env, primitive):
    return []
