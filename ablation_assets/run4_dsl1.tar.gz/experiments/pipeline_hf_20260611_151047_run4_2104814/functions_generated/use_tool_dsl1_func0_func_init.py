def use_tool(env, tool, obstacle):
    return []
