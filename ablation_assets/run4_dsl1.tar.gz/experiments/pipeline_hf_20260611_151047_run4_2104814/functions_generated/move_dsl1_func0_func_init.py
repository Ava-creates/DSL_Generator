def move(env, direction):
    return []
